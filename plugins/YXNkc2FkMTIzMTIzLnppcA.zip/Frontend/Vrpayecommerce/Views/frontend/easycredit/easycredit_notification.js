var easycreditParent = document.getElementsByClassName("ratenkauf by easyCredit")[0].parentElement.parentElement;
easycreditParent.style.backgroundColor = "#eee";
easycreditParent.style.display = "block";
easycreditParent.style.cursor = "not-allowed";

var easycreditInput = easycreditParent.getElementsByTagName('input')[0];
easycreditInput.disabled = true;
easycreditInput.checked = false;


